import os
import shutil
import logging
import zipfile
import re
from config import ACCOUNTS_DIR, SOLD_DIR, DB_PATH
from database.db_manager import DatabaseManager

logger = logging.getLogger(__name__)

class InventoryModule:
    def __init__(self):
        self.db = DatabaseManager(DB_PATH)
        if not os.path.exists(ACCOUNTS_DIR):
            os.makedirs(ACCOUNTS_DIR)

    def sync_physical_files(self):
        """Sincroniza os arquivos da pasta com o banco de dados de forma flexível"""
        if not os.path.exists(ACCOUNTS_DIR):
            logger.error(f"ERRO: Pasta de estoque não encontrada em: {ACCOUNTS_DIR}")
            return 0

        def natural_sort_key(s):
            return [int(text) if text.isdigit() else text.lower() for text in re.split('([0-9]+)', s)]

        current_files = []
        files_in_dir = os.listdir(ACCOUNTS_DIR)
        files_in_dir.sort(key=natural_sort_key)

        for f in files_in_dir:
            file_path = os.path.join(ACCOUNTS_DIR, f)
            if os.path.isfile(file_path):
                current_files.append(f)

        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, filename FROM inventory WHERE status = 'available'")
            db_entries = cursor.fetchall()
            for entry_id, filename in db_entries:
                if filename not in current_files:
                    cursor.execute("DELETE FROM inventory WHERE id = ?", (entry_id,))
            conn.commit()

        added_count = 0
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT filename FROM inventory")
            existing_filenames = {row[0] for row in cursor.fetchall()}

            for f in current_files:
                if f not in existing_filenames:
                    cursor.execute("INSERT INTO inventory (filename, status) VALUES (?, 'available')", (f,))
                    added_count += 1
            conn.commit()
        return added_count

    def organize_stock(self):
        """
        Organiza o estoque:
        1. Renomeia arquivos .dat dentro de ZIPs para guest100067.dat
        2. Coloca arquivos .dat soltos em novos ZIPs (conta1.zip, conta2.zip, etc)
        3. Renomeia o arquivo interno desses novos ZIPs para guest100067.dat
        """
        if not os.path.exists(ACCOUNTS_DIR):
            return 0
            
        def natural_sort_key(s):
            return [int(text) if text.isdigit() else text.lower() for text in re.split('([0-9]+)', s)]

        # Filtra apenas arquivos reais (ignora pastas e arquivos ocultos)
        files = [f for f in os.listdir(ACCOUNTS_DIR) if os.path.isfile(os.path.join(ACCOUNTS_DIR, f)) and not f.startswith('.')]
        files.sort(key=natural_sort_key)
        
        # Pasta temporária para mover os arquivos antes de renomear
        temp_dir = os.path.join(os.path.dirname(ACCOUNTS_DIR), "temp_organize")
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        os.makedirs(temp_dir)
        
        for f in files:
            shutil.move(os.path.join(ACCOUNTS_DIR, f), os.path.join(temp_dir, f))
            
        # Nome fixo solicitado pelo usuário para o arquivo interno
        internal_name = "guest100067.dat"
            
        for i, f in enumerate(files, 1):
            old_path = os.path.join(temp_dir, f)
            new_name = f"conta{i}.zip"
            new_path = os.path.join(ACCOUNTS_DIR, new_name)
            
            if f.lower().endswith('.zip'):
                # Processa ZIP existente
                try:
                    with zipfile.ZipFile(old_path, 'r') as zin:
                        namelist = zin.namelist()
                        # Procura por um arquivo .dat no ZIP
                        dat_files = [m for m in namelist if m.endswith('.dat')]
                        # Se não houver .dat, pega o primeiro arquivo da lista
                        target_member = dat_files[0] if dat_files else namelist[0]
                        content = zin.read(target_member)
                        
                    with zipfile.ZipFile(new_path, 'w', zipfile.ZIP_DEFLATED) as zout:
                        zout.writestr(internal_name, content)
                    os.remove(old_path)
                except Exception as e:
                    logger.error(f"Erro ao processar ZIP {f}: {e}")
                    # Em caso de erro, tenta apenas mover de volta
                    if not os.path.exists(new_path):
                        shutil.move(old_path, new_path)
            else:
                # Se não for ZIP (ex: .dat solto), cria um ZIP novo
                try:
                    with zipfile.ZipFile(new_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                        # Lê o conteúdo do arquivo e grava no ZIP com o nome fixo
                        with open(old_path, 'rb') as f_in:
                            zipf.writestr(internal_name, f_in.read())
                    os.remove(old_path)
                except Exception as e:
                    logger.error(f"Erro ao processar arquivo solto {f}: {e}")
                    if not os.path.exists(new_path):
                        shutil.move(old_path, os.path.join(ACCOUNTS_DIR, f))
        
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

        # Limpa o banco de dados antes de sincronizar para refletir os novos nomes
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM inventory")
            conn.commit()

        return self.sync_physical_files()

    def get_stock_info(self):
        self.sync_physical_files()
        return self.db.get_available_count()

    def get_accounts(self, quantity=1):
        self.sync_physical_files()
        return self.db.get_next_available(quantity)
