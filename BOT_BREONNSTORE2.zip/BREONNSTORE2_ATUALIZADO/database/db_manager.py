import sqlite3
import os
import logging

logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self, db_path):
        self.db_path = db_path
        self._create_tables()
        self._migrate_db()

    def _get_connection(self):
        return sqlite3.connect(self.db_path)

    def _create_tables(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Tabela de usuários (adicionado is_banned)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    balance REAL DEFAULT 0.0,
                    is_admin INTEGER DEFAULT 0,
                    total_spent REAL DEFAULT 0.0,
                    is_banned INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            # Tabela de estoque
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS inventory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    filename TEXT NOT NULL,
                    status TEXT DEFAULT 'available',
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            # Tabela de vendas
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    inventory_id INTEGER,
                    amount REAL,
                    payment_status TEXT,
                    sold_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (inventory_id) REFERENCES inventory (id)
                )
            ''')
            # Tabela de configurações globais
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            ''')

            # Tabela de cupons
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS coupons (
                    code TEXT PRIMARY KEY,
                    type TEXT DEFAULT 'saldo', -- 'saldo' ou 'desconto'
                    value REAL NOT NULL,
                    uses_left INTEGER DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Tabela de uso de cupons (para evitar que o mesmo usuário use o mesmo cupom várias vezes)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS coupon_usage (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    coupon_code TEXT,
                    used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (coupon_code) REFERENCES coupons (code)
                )
            ''')

            # Tabela de Pagamentos (Mercado Pago)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS payments (
                    id TEXT PRIMARY KEY,
                    user_id INTEGER,
                    amount REAL,
                    status TEXT DEFAULT 'pending',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Tabela de Logs Administrativos
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS admin_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    action TEXT,
                    details TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Inicializa multiplicador de bônus de evento
            cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('bonus_multiplier', '1.0')")
            # Inicializa preço de revenda padrão (mesmo preço normal por padrão)
            from config import PRODUCT_PRICE
            cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('reseller_price', ?)", (str(PRODUCT_PRICE),))
            conn.commit()

    def _migrate_db(self):
        """Realiza migrações necessárias no banco de dados"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                # Migrações para a tabela 'users'
                user_columns = [
                    ("total_spent", "REAL DEFAULT 0.0"),
                    ("is_banned", "INTEGER DEFAULT 0"),
                    ("rank_level", "INTEGER DEFAULT 0")
                ]
                for col_name, col_type in user_columns:
                    try:
                        cursor.execute(f"ALTER TABLE users ADD COLUMN {col_name} {col_type}")
                    except sqlite3.OperationalError: pass

                # Migrações para a tabela 'coupons'
                try:
                    cursor.execute("ALTER TABLE coupons ADD COLUMN type TEXT DEFAULT 'saldo'")
                except sqlite3.OperationalError: pass

                try:
                    cursor.execute("ALTER TABLE coupons ADD COLUMN value REAL DEFAULT 0.0")
                except sqlite3.OperationalError: pass

                conn.commit()
        except Exception as e:
            logger.error(f"Erro na migração do banco: {e}")

    def get_user(self, user_id):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT user_id, username, balance, is_admin, total_spent, is_banned, rank_level FROM users WHERE user_id = ?", (user_id,))
            return cursor.fetchone()

    def get_all_users_count(self):
        from config import ADMIN_ID
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM users WHERE user_id != ?", (ADMIN_ID,))
            return cursor.fetchone()[0]

    def get_all_users(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT user_id FROM users WHERE is_banned = 0")
            return [row[0] for row in cursor.fetchall()]

    def get_top_buyers(self, limit=10):
        from config import ADMIN_ID
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Filtra o ADMIN_ID (dono) do ranking
            cursor.execute("SELECT username, total_spent, user_id FROM users WHERE is_banned = 0 AND user_id != ? ORDER BY total_spent DESC LIMIT ?", (ADMIN_ID, limit,))
            return cursor.fetchall()

    def get_user_by_username(self, username):
        if username and username.startswith('@'):
            username = username[1:]
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT user_id, username, balance, is_admin, total_spent, is_banned FROM users WHERE username = ?", (username,))
            return cursor.fetchone()

    def create_user_if_not_exists(self, user_id, username, is_initial_admin=False):
        is_admin_val = 1 if is_initial_admin else 0
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO users (user_id, username, is_admin)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET username=excluded.username
            ''', (user_id, username, is_admin_val))
            conn.commit()

    def set_admin_status(self, user_id, status):
        val = 1 if status else 0
        rank = 3 if status else 0 # Se for admin, coloca nível 3 por padrão
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET is_admin = ?, rank_level = ? WHERE user_id = ?", (val, rank, user_id))
            conn.commit()

    def set_user_rank(self, user_id, level):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Níveis 1 (Admin), 2 (SubDono) e 3 (Dono) são considerados administradores.
            # Nível 6 (Revendedor) NÃO é administrador.
            is_admin = 1 if 1 <= level <= 3 else 0
            cursor.execute("UPDATE users SET rank_level = ?, is_admin = ? WHERE user_id = ?", (level, is_admin, user_id))
            conn.commit()

    def set_ban_status(self, user_id, status):
        val = 1 if status else 0
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (val, user_id))

            action = "BANIR_USUARIO" if status else "DESBANIR_USUARIO"
            cursor.execute("INSERT INTO admin_logs (user_id, action, details) VALUES (?, ?, ?)",
                         (0, action, f"Usuário ID: {user_id}"))

            conn.commit()

    def update_balance(self, user_id, amount):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))

            action = "ADD_SALDO" if amount > 0 else "REM_SALDO"
            cursor.execute("INSERT INTO admin_logs (user_id, action, details) VALUES (?, ?, ?)",
                         (user_id, action, f"Quantia: R$ {abs(amount):.2f}"))

            conn.commit()

    def add_to_inventory(self, filename):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('INSERT INTO inventory (filename) VALUES (?)', (filename,))
            conn.commit()

    def get_available_count(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM inventory WHERE status = 'available'")
            res = cursor.fetchone()
            return res[0] if res else 0

    def get_sold_count(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM inventory WHERE status = 'sold'")
            res = cursor.fetchone()
            return res[0] if res else 0

    def get_next_available(self, limit=1):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, filename FROM inventory WHERE status = 'available' LIMIT ?", (limit,))
            return cursor.fetchall()

    def get_and_reserve_accounts(self, user_id, quantity, amount_per_item):
        """Busca, reserva e marca como vendido em uma única transação atômica"""
        with self._get_connection() as conn:
            conn.execute("BEGIN TRANSACTION")
            try:
                cursor = conn.cursor()
                # Seleciona as contas disponíveis
                cursor.execute(
                    "SELECT id, filename FROM inventory WHERE status = 'available' LIMIT ?",
                    (quantity,)
                )
                accounts = cursor.fetchall()

                if len(accounts) < quantity:
                    conn.rollback()
                    return None

                # Marca cada conta como vendida imediatamente
                for acc_id, filename in accounts:
                    cursor.execute(
                        "UPDATE inventory SET status = 'sold' WHERE id = ?",
                        (acc_id,)
                    )
                    cursor.execute(
                        "INSERT INTO sales (user_id, inventory_id, amount, payment_status) VALUES (?, ?, ?, ?)",
                        (user_id, acc_id, amount_per_item, 'completed')
                    )

                # Atualiza o gasto total do usuário
                total_amount = amount_per_item * len(accounts)
                cursor.execute(
                    "UPDATE users SET total_spent = total_spent + ? WHERE user_id = ?",
                    (total_amount, user_id)
                )

                # Log da venda em massa
                cursor.execute(
                    "INSERT INTO admin_logs (user_id, action, details) VALUES (?, ?, ?)",
                    (user_id, "VENDA_EM_MASSA", f"Qtd: {len(accounts)} | Total: R$ {total_amount:.2f}")
                )

                conn.commit()
                return accounts
            except Exception as e:
                conn.rollback()
                logger.error(f"Erro ao reservar contas: {e}")
                return None

    def mark_as_sold(self, inventory_id, user_id, amount):
        """Marca um item como vendido e registra a venda"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE inventory SET status = 'sold' WHERE id = ?", (inventory_id,))
            cursor.execute("INSERT INTO sales (user_id, inventory_id, amount, payment_status) VALUES (?, ?, ?, ?)",
                         (user_id, inventory_id, amount, 'completed'))
            cursor.execute("UPDATE users SET total_spent = total_spent + ? WHERE user_id = ?", (amount, user_id))

            # Log da venda
            cursor.execute("INSERT INTO admin_logs (user_id, action, details) VALUES (?, ?, ?)",
                         (user_id, "VENDA_CONCLUIDA", f"Valor: R$ {amount:.2f} | Item ID: {inventory_id}"))

            conn.commit()

    def register_sale(self, user_id, inventory_id, amount):
        self.mark_as_sold(inventory_id, user_id, amount)
    def get_total_profit(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Soma o total_spent de todos os usuários (exceto o admin/dono)
            # Isso reflete melhor os lucros totais reais da loja
            from config import ADMIN_ID
            cursor.execute("SELECT SUM(total_spent) FROM users WHERE user_id != ?", (ADMIN_ID,))
            res = cursor.fetchone()
            return res[0] if res and res[0] else 0.0

    def set_setting(self, key, value):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
            conn.commit()

    def get_setting(self, key, default=None):
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
                row = cursor.fetchone()
                return row[0] if row else default
        except:
            return default

    def reset_rank(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET total_spent = 0.0")
            conn.commit()

    def reset_inventory(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM inventory")
            cursor.execute("DELETE FROM sales")
            conn.commit()

    def add_coupon(self, code, value, uses):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT OR REPLACE INTO coupons (code, type, value, uses_left) VALUES (?, ?, ?, ?)", (code.upper(), 'desconto', value, uses))
            conn.commit()

    def get_coupon(self, code):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT code, type, value, uses_left FROM coupons WHERE code = ?", (code.upper(),))
            return cursor.fetchone()

    def get_all_coupons(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Busca os cupons e conta quantos usos cada um teve na tabela coupon_usage
            cursor.execute("""
                SELECT c.code, c.type, c.value, c.uses_left, 
                (SELECT COUNT(*) FROM coupon_usage WHERE coupon_code = c.code) as used_count
                FROM coupons c
            """)
            return cursor.fetchall()

    def delete_coupon(self, code):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Tenta deletar em maiúsculo primeiro
            cursor.execute("DELETE FROM coupons WHERE code = ?", (code.upper(),))
            deleted = cursor.rowcount > 0
            if not deleted:
                # Se não deletou nada, tenta com o código original (caso tenha sido criado em minúsculo antes da trava)
                cursor.execute("DELETE FROM coupons WHERE code = ?", (code,))
                deleted = cursor.rowcount > 0
            
            # Limpa o histórico de uso do cupom deletado
            cursor.execute("DELETE FROM coupon_usage WHERE coupon_code = ?", (code.upper(),))
            cursor.execute("DELETE FROM coupon_usage WHERE coupon_code = ?", (code,))
            
            conn.commit()
            return deleted

    def validate_coupon(self, user_id, code):
        """Apenas valida se o cupom existe e pode ser usado pelo usuário"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM coupon_usage WHERE user_id = ? AND coupon_code = ?", (user_id, code.upper()))
            if cursor.fetchone():
                return False, "Você já usou este cupom!"

            cursor.execute("SELECT type, value, uses_left FROM coupons WHERE code = ?", (code.upper(),))
            coupon = cursor.fetchone()
            if not coupon:
                return False, "Cupom inválido ou inexistente."

            c_type, value, uses_left = coupon
            if uses_left <= 0:
                return False, "Este cupom atingiu o limite de usos."

            return True, {"type": c_type, "value": value}

    def use_coupon(self, user_id, code):
        """Consome o cupom definitivamente (apenas desconto)"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Verifica se o usuário já usou este cupom
            cursor.execute("SELECT id FROM coupon_usage WHERE user_id = ? AND coupon_code = ?", (user_id, code.upper()))
            if cursor.fetchone():
                return False, "Você já usou este cupom!"

            # Busca o cupom
            cursor.execute("SELECT type, value, uses_left FROM coupons WHERE code = ?", (code.upper(),))
            coupon = cursor.fetchone()

            if not coupon:
                return False, "Cupom inválido ou inexistente."

            c_type, value, uses_left = coupon
            if uses_left <= 0:
                return False, "Este cupom já atingiu o limite de usos."

            if c_type != 'desconto':
                return False, "Este cupom não é de desconto."

            # Registra o uso
            cursor.execute("INSERT INTO coupon_usage (user_id, coupon_code) VALUES (?, ?)", (user_id, code.upper()))
            cursor.execute("UPDATE coupons SET uses_left = uses_left - 1 WHERE code = ?", (code.upper(),))

            # Log do uso
            cursor.execute("INSERT INTO admin_logs (user_id, action, details) VALUES (?, ?, ?)",
                         (user_id, "USO_CUPOM_OFF", f"Cupom: {code.upper()} | Desconto: {value}%"))
            conn.commit()
            return True, ("desconto", value)

    def add_admin_log(self, user_id, action, details):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO admin_logs (user_id, action, details) VALUES (?, ?, ?)", (user_id, action, details))
            conn.commit()

    def add_payment(self, payment_id, user_id, amount):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO payments (id, user_id, amount) VALUES (?, ?, ?)", (payment_id, user_id, amount))
            conn.commit()

    def get_payment(self, payment_id):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, user_id, amount, status FROM payments WHERE id = ?", (payment_id,))
            return cursor.fetchone()

    def update_payment_status(self, payment_id, status):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE payments SET status = ? WHERE id = ?", (status, payment_id))
            conn.commit()

    def get_admin_logs(self, limit=20):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT l.timestamp, l.user_id, u.username, l.action, l.details
                FROM admin_logs l
                LEFT JOIN users u ON l.user_id = u.user_id
                ORDER BY l.timestamp DESC LIMIT ?
            """, (limit,))
            return cursor.fetchall()
