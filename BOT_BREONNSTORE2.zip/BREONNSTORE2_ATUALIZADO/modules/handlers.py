import asyncio
import traceback
import mercadopago
import shutil
import qrcode
import io
import os
import sys
import re
import zipfile
import logging
import json
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from config import (
    STORE_NAME, PRODUCT_NAME, PRODUCT_PRICE as DEFAULT_PRODUCT_PRICE,
    ADMIN_ID, LOG_CHANNEL_ID, FEEDBACK_CHANNEL_ID, ACCOUNTS_DIR, SOLD_DIR,
    MERCADOPAGO_TOKEN, DONO_USERNAME, BASE_DIR
)
from modules.inventory import InventoryModule

# Inicialização
logger = logging.getLogger(__name__)
inventory = InventoryModule()

# Carrega preço do banco ou usa o padrão do config
PRODUCT_PRICE = float(inventory.db.get_setting('product_price', DEFAULT_PRODUCT_PRICE))

# --- AUXILIARES ---

async def edit_or_reply(update, text, reply_markup=None, parse_mode='Markdown'):
    if update.callback_query:
        query = update.callback_query
        try:
            if query.message.photo:
                await query.edit_message_caption(caption=text, reply_markup=reply_markup, parse_mode=parse_mode)
            else:
                await query.edit_message_text(text, reply_markup=reply_markup, parse_mode=parse_mode)
        except Exception:
            await query.message.reply_text(text, reply_markup=reply_markup, parse_mode=parse_mode)
    else:
        if update.message:
            await update.message.reply_text(text, reply_markup=reply_markup, parse_mode=parse_mode)

def is_owner(user_id, username):
    return str(user_id) == str(ADMIN_ID) or (username and username.lower() == DONO_USERNAME.lower())

def is_subdono(user_id, username):
    if is_owner(user_id, username): return True
    u = inventory.db.get_user(user_id)
    return u and u[6] >= 2 # Nível 2 = SubDono

def is_admin_user(user_id, username):
    if is_owner(user_id, username): return True
    u = inventory.db.get_user(user_id)
    return u and u[6] >= 1 # Nível 1 = Admin

def is_reseller_user(user_id, username):
    if is_owner(user_id, username): return True
    u = inventory.db.get_user(user_id)
    return u and u[6] >= 6 # Nível 6 = Revendedor

async def send_log(context, action, details, user=None):
    try:
        text = f"🛡️ *LOG STAFF*\n⚡ *Ação:* {action}\n📝 *Detalhes:* {details}"
        if user: text += f"\n👤 *Usuário:* @{user.username or user.id}"
        await context.bot.send_message(chat_id=LOG_CHANNEL_ID, text=text, parse_mode='Markdown')
    except: pass

async def send_feedback_to_channel(context, user, message_text=None, photo=None):
    try:
        caption = f"🌟 *NOVO FEEDBACK - {STORE_NAME}*\n\n👤 *Cliente:* @{user.username or user.id}\n✅ *Status:* Compra Entregue / Feedback Recebido"
        if message_text:
            caption += f"\n\n💬 *Mensagem:* {message_text}"
        
        if photo:
            await context.bot.send_photo(chat_id=FEEDBACK_CHANNEL_ID, photo=photo, caption=caption, parse_mode='Markdown')
        else:
            await context.bot.send_message(chat_id=FEEDBACK_CHANNEL_ID, text=caption, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Erro ao enviar feedback para o canal: {e}")

async def admin_logs(update: Update, context: ContextTypes.DEFAULT_TYPE, message: str):
    try:
        user = update.effective_user
        log_text = f"🛡️ *ADMIN LOG*\n👤 @{user.username or user.id}\n📝 {message}"
        await context.bot.send_message(chat_id=LOG_CHANNEL_ID, text=log_text, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Erro ao enviar admin log: {e}")

async def resgatar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("💎 Comando /resgatar funcionando!")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    inventory.db.create_user_if_not_exists(user.id, user.username)

    u = inventory.db.get_user(user.id)
    if u and u[5]: # is_banned
        return await update.message.reply_text("🚫 Você está banido deste bot.")

    welcome_text = (
        f"✨ *{STORE_NAME}* ✨\n"
        f"👤 *Usuário:* {user.first_name}\n"
        f"💳 *Saldo:* `R$ {u[2]:.2f}`\n\n"
        f"📦 *Item:* `{PRODUCT_NAME}`\n"
        f"💰 *Preço:* `R$ {PRODUCT_PRICE:.2f}`"
    )

    keyboard = [
        [InlineKeyboardButton("🛒 COMPRAR", callback_data='buy_menu'), InlineKeyboardButton("💳 SALDO", callback_data='add_balance_info')],
        [InlineKeyboardButton("👤 PERFIL", callback_data='profile'), InlineKeyboardButton("📦 ESTOQUE", callback_data='stock')],
        [InlineKeyboardButton("🏆 RANKING", callback_data='rank'), InlineKeyboardButton("🆘 SUPORTE", callback_data='support')]
    ]
    keyboard.insert(1, [InlineKeyboardButton("💎 MENU REVENDA 💎", callback_data='reseller_menu')])

    if is_admin_user(user.id, user.username):
        keyboard.append([InlineKeyboardButton("🛡️ PAINEL STAFF 🛡️", callback_data='admin_panel')])

    if update.message:
        await update.message.reply_text(welcome_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
    else:
        await edit_or_reply(update, welcome_text, reply_markup=InlineKeyboardMarkup(keyboard))

async def admin_confirmar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    if not context.args or len(context.args) < 2:
        return await update.message.reply_text("📝 Uso: `/confirmar <@user> <valor>`")

    try:
        identifier = context.args[0]
        amount = float(context.args[1])
        user_data = inventory.db.get_user(int(identifier)) if identifier.isdigit() else inventory.db.get_user_by_username(identifier)

        if user_data:
            inventory.db.update_balance(user_data[0], amount)
            await update.message.reply_text(f"✅ *SALDO ADICIONADO:* @{user_data[1]}\n💰 Quantia: `R$ {amount:.2f}`", parse_mode='Markdown')
            await context.bot.send_message(chat_id=user_data[0], text=f"💰 *SALDO ADICIONADO!*\nFoi creditado `R$ {amount:.2f}` em sua conta.", parse_mode='Markdown')
            await send_log(context, "ADD_SALDO_MANUAL", f"R$ {amount:.2f} para @{user_data[1]}", update.effective_user)
    except Exception as e: await update.message.reply_text(f"❌ Erro: {e}")

async def admin_addsaldo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await admin_confirmar(update, context)

async def admin_setcargo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_subdono(update.effective_user.id, update.effective_user.username): return
    if not context.args or len(context.args) < 2:
        return await update.message.reply_text("📝 Uso: `/setcargo <ID_OU_@USER> <NIVEL>`\n\n1: Admin\n2: SubDono\n3: Dono\n6: Revendedor")
    try:
        identifier, level = context.args[0], int(context.args[1])
        user_data = inventory.db.get_user(int(identifier)) if identifier.isdigit() else inventory.db.get_user_by_username(identifier)
        if user_data:
            inventory.db.set_user_rank(user_data[0], level)
            await update.message.reply_text(f"✅ Cargo de @{user_data[1]} atualizado para nível {level}!")
            await send_log(context, "SET_CARGO", f"Nível {level} para @{user_data[1]}", update.effective_user)
        else: await update.message.reply_text("❌ Usuário não encontrado.")
    except Exception as e: await update.message.reply_text(f"❌ Erro: {e}")

async def admin_remcargo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_subdono(update.effective_user.id, update.effective_user.username): return
    if not context.args: return await update.message.reply_text("📝 Uso: `/remcargo <ID_OU_@USER> [NIVEL]`\n\nExemplo: `/remcargo @user 6` para remover apenas revendedor.\nSe não informar o nível, todos os cargos serão removidos.")
    try:
        identifier = context.args[0]
        target_level = int(context.args[1]) if len(context.args) > 1 else None
        
        user_data = inventory.db.get_user(int(identifier)) if identifier.isdigit() else inventory.db.get_user_by_username(identifier)
        if user_data:
            current_level = user_data[6]
            # Se for o dono tentando remover o próprio cargo de revendedor (nível 6)
            if str(update.effective_user.id) == str(user_data[0]) and current_level == 6:
                inventory.db.set_user_rank(user_data[0], 0)
                await update.message.reply_text("✅ Seu cargo de revendedor foi removido com sucesso!")
                return

            if target_level is not None:
                if current_level == target_level:
                    inventory.db.set_user_rank(user_data[0], 0)
                    await update.message.reply_text(f"✅ Cargo nível {target_level} removido de @{user_data[1]}!")
                else:
                    await update.message.reply_text(f"❌ O usuário @{user_data[1]} não possui o cargo nível {target_level}. (Nível atual: {current_level})")
                    return
            else:
                inventory.db.set_user_rank(user_data[0], 0)
                await update.message.reply_text(f"✅ Todos os cargos de @{user_data[1]} foram removidos!")
            
            await send_log(context, "REM_CARGO", f"Removido de @{user_data[1]} (Nível especificado: {target_level if target_level else 'Todos'})", update.effective_user)
        else: await update.message.reply_text("❌ Usuário não encontrado.")
    except Exception as e: await update.message.reply_text(f"❌ Erro: {e}")

async def admin_tirar_revenda(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando rápido para o dono tirar o próprio cargo de revendedor ou de outro usuário"""
    user = update.effective_user
    # Se não passar argumentos, tenta tirar de si mesmo
    identifier = context.args[0] if context.args else str(user.id)
    
    try:
        user_data = inventory.db.get_user(int(identifier)) if identifier.isdigit() else inventory.db.get_user_by_username(identifier)
        if user_data:
            # Apenas o dono ou sub-dono pode tirar de outros, mas qualquer um pode tentar tirar de si mesmo (se for revendedor)
            if str(user.id) != str(user_data[0]) and not is_subdono(user.id, user.username):
                return await update.message.reply_text("❌ Você não tem permissão para remover cargos de outros usuários.")
            
            if user_data[6] == 6: # Nível 6 = Revendedor
                inventory.db.set_user_rank(user_data[0], 0)
                msg = "✅ Cargo de revendedor removido de si mesmo!" if str(user.id) == str(user_data[0]) else f"✅ Cargo de revendedor removido de @{user_data[1]}!"
                await update.message.reply_text(msg)
                await send_log(context, "TIRAR_REVENDA", f"Removido de @{user_data[1]}", user)
            else:
                await update.message.reply_text(f"❌ @{user_data[1]} não possui o cargo de revendedor.")
        else:
            await update.message.reply_text("❌ Usuário não encontrado.")
    except Exception as e:
        await update.message.reply_text(f"❌ Erro: {e}")

async def admin_sync_estoque(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    status_msg = await update.message.reply_text("🔄 Sincronizando estoque...")
    added = inventory.sync_stock()
    await status_msg.edit_text(f"✅ Estoque sincronizado!\n📦 `{added}` novas contas adicionadas.")
    await send_log(context, "SYNC_ESTOQUE", f"{added} contas", update.effective_user)

async def admin_anuncio(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    msg_text = update.message.caption[9:] if update.message.photo else update.message.text[9:]
    if not msg_text: return await update.message.reply_text("📝 Uso: `/anuncio <mensagem>`")
    
    users = inventory.db.get_all_users()
    sent, failed = 0, 0
    status = await update.message.reply_text(f"📢 Enviando anúncio para {len(users)} usuários...")
    
    for u_id in users:
        try:
            if update.message.photo:
                await context.bot.send_photo(chat_id=u_id, photo=update.message.photo[-1].file_id, caption=msg_text, parse_mode='Markdown')
            else:
                await context.bot.send_message(chat_id=u_id, text=msg_text, parse_mode='Markdown')
            sent += 1
            await asyncio.sleep(0.05)
        except: failed += 1
    await status.edit_text(f"✅ Anúncio finalizado!\n👤 Enviado: `{sent}`\n❌ Falhas: `{failed}`")

async def admin_evento(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id, update.effective_user.username): return
    if not context.args: return await update.message.reply_text("📝 Uso: `/evento <multiplicador>` (Ex: 1.5 para 50% de bônus)")
    try:
        mult = float(context.args[0])
        inventory.db.set_setting('bonus_multiplier', mult)
        await update.message.reply_text(f"✅ Multiplicador de bônus definido para `{mult}x`!")
        await send_log(context, "SET_EVENTO", f"{mult}x", update.effective_user)
    except: await update.message.reply_text("❌ Valor inválido.")

async def admin_reset(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id, update.effective_user.username): return
    if not context.args: return await update.message.reply_text("📝 Uso: `/reset rank` ou `/reset estoque`")
    cmd = context.args[0].lower()
    if cmd == 'rank':
        inventory.db.reset_rank()
        await update.message.reply_text("✅ Ranking resetado!")
    elif cmd == 'estoque':
        inventory.db.reset_inventory()
        await update.message.reply_text("✅ Estoque resetado!")

async def admin_settoken(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id, update.effective_user.username): return
    if not context.args: return await update.message.reply_text("📝 Uso: `/settoken <MERCADOPAGO_TOKEN>`")
    # Nota: No ambiente real, isso deveria atualizar o .env ou config.py permanentemente
    global MERCADOPAGO_TOKEN
    MERCADOPAGO_TOKEN = context.args[0]
    await update.message.reply_text("✅ Token do Mercado Pago atualizado!")

async def admin_banir(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    if not context.args: return await update.message.reply_text("📝 Uso: `/banir <ID_OU_@USER>`")
    try:
        identifier = context.args[0]
        user_data = inventory.db.get_user(int(identifier)) if identifier.isdigit() else inventory.db.get_user_by_username(identifier)
        if user_data:
            inventory.db.set_ban_status(user_data[0], True)
            await update.message.reply_text(f"🚫 Usuário @{user_data[1]} banido!")
            await send_log(context, "BANIR_USUARIO", f"@{user_data[1]}", update.effective_user)
        else: await update.message.reply_text("❌ Usuário não encontrado.")
    except Exception as e: await update.message.reply_text(f"❌ Erro: {e}")

async def admin_desbanir(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    if not context.args: return await update.message.reply_text("📝 Uso: `/desbanir <ID_OU_@USER>`")
    try:
        identifier = context.args[0]
        user_data = inventory.db.get_user(int(identifier)) if identifier.isdigit() else inventory.db.get_user_by_username(identifier)
        if user_data:
            inventory.db.set_ban_status(user_data[0], False)
            await update.message.reply_text(f"✅ Usuário @{user_data[1]} desbanido!")
            await send_log(context, "DESBANIR_USUARIO", f"@{user_data[1]}", update.effective_user)
        else: await update.message.reply_text("❌ Usuário não encontrado.")
    except Exception as e: await update.message.reply_text(f"❌ Erro: {e}")

async def admin_estatisticas(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    users_count = inventory.db.get_all_users_count()
    profit = inventory.db.get_total_profit()
    stock = inventory.get_stock_info()
    sold_count = inventory.db.get_sold_count()
    text = (f"📊 *ESTATÍSTICAS DA LOJA*\n\n"
            f"👤 Usuários: `{users_count}`\n"
            f"📦 Estoque: `{stock}`\n"
            f"✅ Vendidos: `{sold_count}`\n"
            f"💰 Lucro Total: `R$ {profit:.2f}`")
    await update.message.reply_text(text, parse_mode='Markdown')

async def admin_ver_cupons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    cupons = inventory.db.get_all_cupons() if hasattr(inventory.db, 'get_all_cupons') else inventory.db.get_all_coupons()
    if not cupons: return await update.message.reply_text("🎫 Nenhum cupom ativo.")
    text = "🎫 *CUPONS ATIVOS:*\n\n"
    for code, type, val, left, used in cupons:
        text += f"• `{code}`: {val}% | Restam: {left} | Usados: {used}\n"
    await update.message.reply_text(text, parse_mode='Markdown')

async def admin_apagar_cupom(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    if not context.args: return await update.message.reply_text("📝 Uso: `/delcupom <CODIGO>`")
    code = context.args[0].upper()
    if inventory.db.delete_coupon(code):
        await update.message.reply_text(f"✅ Cupom `{code}` removido!")
    else: await update.message.reply_text("❌ Cupom não encontrado.")

async def cmd_comandos_dono(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id, update.effective_user.username): return
    text = (
        "👑 *COMANDOS DO DONO*\n\n"
        "• `/setcargo <id/@user> <nivel>`\n"
        "• `/remcargo <id/@user>`\n"
        "• `/evento <mult>`\n"
        "• `/reset <rank/estoque>`\n"
        "• `/settoken <token>`\n"
        "• `/reiniciar` - Reinicia o bot"
    )
    await update.message.reply_text(text, parse_mode='Markdown')

async def admin_organizar_estoque(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    status_msg = await update.message.reply_text("🧹 Organizando estoque...")
    try:
        added = inventory.organize_stock()
        await status_msg.edit_text(f"✅ *ESTOQUE ORGANIZADO!*\n📦 Total: `{added}` contas.", parse_mode='Markdown')
    except Exception as e:
        await status_msg.edit_text(f"❌ Erro: {e}")

async def admin_setpreco(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    if not context.args: return await update.message.reply_text("📝 Uso: `/setpreco <valor>`")
    try:
        price = float(context.args[0])
        inventory.db.set_setting('product_price', price)
        
        # Atualiza a variável global PRODUCT_PRICE em tempo de execução
        global PRODUCT_PRICE
        PRODUCT_PRICE = price
        
        await update.message.reply_text(f"✅ Preço normal atualizado: `R$ {price:.2f}`", parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Erro ao definir preço: {e}")
        await update.message.reply_text("❌ Valor inválido.")

async def admin_setprecorevenda(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    if not context.args: return await update.message.reply_text("📝 Uso: `/setprecorevenda <valor>`")
    try:
        price = float(context.args[0])
        inventory.db.set_setting('reseller_price', price)
        await update.message.reply_text(f"✅ Preço revenda atualizado: `R$ {price:.2f}`", parse_mode='Markdown')
    except: await update.message.reply_text("❌ Valor inválido.")

async def admin_criar_cupom(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    if not context.args or len(context.args) < 3:
        return await update.message.reply_text("📝 Uso: `/cupom <CODIGO> <DESCONTO_%> <USOS>`")

    try:
        code, val, uses = context.args[0], float(context.args[1]), int(context.args[2])
        inventory.db.add_coupon(code, val, uses)
        await update.message.reply_text(f"✅ Cupom `{code.upper()}` criado!\n📉 Desconto: `{val}%` | 👥 Usos: `{uses}`")
        await send_log(context, "CRIAR_CUPOM", f"Código: {code.upper()} | {val}% | {uses} usos", update.effective_user)
    except Exception as e: await update.message.reply_text(f"❌ Erro: {e}")

async def admin_enviar_contas(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    if not context.args or len(context.args) < 2: return await update.message.reply_text("📝 Uso: `/enviar <ID_OU_@USER> <QUANTIDADE>`")
    try:
        identifier, qty = context.args[0], int(context.args[1])
        user_data = inventory.db.get_user(int(identifier)) if identifier.isdigit() else inventory.db.get_user_by_username(identifier)
        if not user_data: return await update.message.reply_text("❌ Usuário não encontrado.")
        accounts = inventory.db.get_and_reserve_accounts(user_data[0], qty, 0.0)
        if not accounts: return await update.message.reply_text(f"❌ Estoque insuficiente.")
        
        sent_count = 0
        tutorial_button = InlineKeyboardMarkup([[InlineKeyboardButton("🎥 TUTORIAL", url="https://youtu.be/UrZfPCLQLaw")]])
        for acc_id, filename in accounts:
            file_path = os.path.join(ACCOUNTS_DIR, filename)
            if os.path.exists(file_path):
                with open(file_path, 'rb') as f:
                    await context.bot.send_document(chat_id=user_data[0], document=f, caption=f"🎁 *CONTA STAFF!*\n📦 Qtd: `{sent_count+1}/{qty}`", reply_markup=tutorial_button, parse_mode='Markdown')
                dest_path = os.path.join(SOLD_DIR, filename)
                shutil.move(file_path, dest_path)
                sent_count += 1
        await update.message.reply_text(f"✅ `{sent_count}` contas enviadas para @{user_data[1]}.")
    except Exception as e: await update.message.reply_text(f"❌ Erro: {e}")

async def admin_reiniciar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id, update.effective_user.username): return
    await update.message.reply_text("🔄 *REINICIANDO SISTEMA...*\n\nAs alterações nos arquivos serão aplicadas agora.", parse_mode='Markdown')
    
    # Fecha o loop do bot de forma limpa antes de reiniciar
    context.application.stop_running()
    
    # Reinicia o processo atual
    os.execl(sys.executable, sys.executable, *sys.argv)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id, user = query.from_user.id, query.from_user
    
    u = inventory.db.get_user(user_id)
    if u and u[5]: return await query.answer("🚫 Você está banido.", show_alert=True)

    if query.data == 'back': await start(update, context)
    elif query.data == 'stock': await cmd_estoque(update, context)
    elif query.data == 'profile': await cmd_perfil(update, context)
    elif query.data == 'rank': await cmd_rank(update, context)
    elif query.data == 'support': await cmd_suporte(update, context)

    elif query.data == 'reseller_menu':
        count = inventory.get_stock_info()
        reseller_price = float(inventory.db.get_setting('reseller_price', 0.40))
        text = (f"💎 *MENU DE REVENDA*\n\n📦 Produto: {PRODUCT_NAME}\n💰 Preço Revenda: `R$ {reseller_price:.2f}`\n📦 Estoque: `{count}`\n💡 Preço especial para qualquer quantidade!")
        keyboard = []
        if count >= 1: keyboard.append([InlineKeyboardButton("🛒 COMPRAR x20 (REVENDA)", callback_data='buy_qty_20_reseller')])
        if count >= 5: keyboard.append([InlineKeyboardButton("🛒 COMPRAR x30 (REVENDA)", callback_data='buy_qty_30_reseller')])
        if count >= 10: keyboard.append([InlineKeyboardButton("🛒 COMPRAR 50x (REVENDA)", callback_data='buy_qty_50_reseller')])
        keyboard.append([InlineKeyboardButton("⌨️ DIGITAR QUANTIDADE", callback_data='buy_manual_qty_reseller')])
        keyboard.append([InlineKeyboardButton("⬅️ VOLTAR", callback_data='back')])
        await edit_or_reply(update, text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data == 'admin_panel':
        if not is_admin_user(user_id, user.username): return await query.answer("❌ Acesso negado!", show_alert=True)
        text = "🛡️ *PAINEL ADMINISTRATIVO*"
        keyboard = [
            [InlineKeyboardButton("📊 ESTATÍSTICAS", callback_data='help_stats'), InlineKeyboardButton("🔄 SYNC ESTOQUE", callback_data='help_sync')],
            [InlineKeyboardButton("🧹 ORGANIZAR", callback_data='help_organizar'), InlineKeyboardButton("📢 ANÚNCIO", callback_data='help_anuncio')],
            [InlineKeyboardButton("💎 PREÇO REVENDA", callback_data='help_reseller'), InlineKeyboardButton("💰 PREÇO NORMAL", callback_data='help_price')],
            [InlineKeyboardButton("⬅️ VOLTAR", callback_data='back')]
        ]
        await edit_or_reply(update, text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data.startswith('help_'):
        cmd = query.data.split('_')[1]
        helps = {'stats': "📊 `/stats`", 'sync': "🔄 `/sync`", 'organizar': "🧹 `/organizar`", 'anuncio': "📢 `/anuncio <msg>`", 'reseller': "💎 `/setprecorevenda <valor>`", 'price': "💰 `/setpreco <valor>`"}
        await query.answer(helps.get(cmd, "Comando Staff"), show_alert=True)

    elif query.data == 'buy_menu' or query.data.startswith('buy_update_'):
        count = inventory.get_stock_info()
        if count <= 0: return await edit_or_reply(update, "❌ *ESGOTADO*", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ VOLTAR", callback_data='back')]]))
        qty = int(query.data.split('_')[2]) if query.data.startswith('buy_update_') else 1
        is_reseller = is_reseller_user(user_id, user.username)
        price = float(inventory.db.get_setting('reseller_price', 0.40)) if is_reseller else PRODUCT_PRICE
        total = price * qty
        text = (f"🛒 *MENU DE COMPRA*\n\n📦 Produto: {PRODUCT_NAME}\n💵 Preço: `R$ {price:.2f}`\n📦 Estoque: `{count}`\n\n🔢 Quantidade: `{qty}`\n💰 Total: `R$ {total:.2f}`")
        keyboard = [
            [InlineKeyboardButton("➖", callback_data=f'buy_update_{max(1, qty-1)}'), InlineKeyboardButton(f"{qty}x", callback_data='none'), InlineKeyboardButton("➕", callback_data=f'buy_update_{min(count, qty+1)}')],
            [InlineKeyboardButton("⌨️ DIGITAR QUANTIDADE", callback_data='buy_manual_qty')],
            [InlineKeyboardButton(f"✅ FINALIZAR (R$ {total:.2f})", callback_data=f'buy_qty_{qty}_reseller' if is_reseller else f'buy_qty_{qty}')],
            [InlineKeyboardButton("⬅️ VOLTAR", callback_data='back')]
        ]
        await edit_or_reply(update, text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data == 'buy_manual_qty' or query.data == 'buy_manual_qty_reseller':
        is_reseller = (query.data == 'buy_manual_qty_reseller')
        context.user_data[user_id] = {'waiting_buy_qty': True, 'is_reseller_waiting': is_reseller}
        min_qty = 1
        text = f"🔢 *DIGITE A QUANTIDADE:* \n\n📦 Estoque: `{inventory.get_stock_info()}`\n⚠️ Mínimo: `{min_qty}x`\n💡 Digite apenas números."
        await edit_or_reply(update, text)

    elif query.data.startswith('buy_qty_'):
        parts = query.data.split('_')
        qty, is_reseller = int(parts[2]), len(parts) > 3 and parts[3] == 'reseller'
        
        if is_reseller:
            price = float(inventory.db.get_setting('reseller_price', 0.40))
        else:
            price = PRODUCT_PRICE
            
        total = price * qty
        
        if total < 0.29:
            return await query.answer(f"❌ Valor mínimo para compra: R$ 0.29(Total atual: R$ {total:.2f})", show_alert=True)

        context.user_data[user_id] = {'qty': qty, 'total': total, 'is_reseller': is_reseller}
        text = (f"🛒 *CONFIRMAR COMPRA*\n\n📦 Produto: {PRODUCT_NAME}\n🔢 Qtd: `{qty}`\n💰 Total: `R$ {total:.2f}`")
        keyboard = [
            [InlineKeyboardButton("💰 PAGAR COM SALDO", callback_data='pay_balance')],
            [InlineKeyboardButton("⚡ PAGAR VIA PIX (GERAR QR)", callback_data='pay_pix')]
        ]
        if not is_reseller:
            keyboard.append([InlineKeyboardButton("🎫 USAR CUPOM (%)", callback_data='apply_coupon')])
            
        keyboard.append([InlineKeyboardButton("⬅️ VOLTAR", callback_data='reseller_menu' if is_reseller else 'buy_menu')])
        await edit_or_reply(update, text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data == 'pay_balance':
        u_data = context.user_data.get(user_id)
        if not u_data: return await query.answer("❌ Sessão expirada.")
        qty, total = u_data.get('qty', 1), u_data.get('total', PRODUCT_PRICE)
        user_data = inventory.db.get_user(user_id)
        if user_data[2] >= total:
            accounts = inventory.db.get_and_reserve_accounts(user_id, qty, total/qty)
            if accounts:
                inventory.db.update_balance(user_id, -total)
                
                # Registra o uso do cupom se houver um aplicado
                coupon_code = u_data.get('coupon')
                if coupon_code:
                    inventory.db.use_coupon(user_id, coupon_code)
                
                await edit_or_reply(update, f"✅ *PAGAMENTO APROVADO!*\n\n⏳ *ENTREGANDO {qty}x...*")
                tutorial_button = InlineKeyboardMarkup([[InlineKeyboardButton("🎥 TUTORIAL", url="https://youtu.be/UrZfPCLQLaw")]])
                for acc_id, filename in accounts:
                    file_path = os.path.join(ACCOUNTS_DIR, filename)
                    if os.path.exists(file_path):
                        with open(file_path, 'rb') as f: await context.bot.send_document(chat_id=user_id, document=f, caption=f"🎁 *CONTA ENTREGUE!*", reply_markup=tutorial_button, parse_mode='Markdown')
                        dest_path = os.path.join(SOLD_DIR, filename)
                        shutil.move(file_path, dest_path)
                context.user_data[user_id] = {'waiting_feedback': True}
            else: await edit_or_reply(update, "❌ Estoque insuficiente!")
        else: await edit_or_reply(update, f"❌ Saldo insuficiente! (R$ {total:.2f})", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("💳 RECARREGAR", callback_data='add_balance_info')],[InlineKeyboardButton("⬅️ VOLTAR", callback_data='back')]]))

    elif query.data == 'pay_pix':
        u_data = context.user_data.get(user_id)
        if not u_data: return await query.answer("❌ Sessão expirada.")
        qty, total = u_data.get('qty', 1), u_data.get('total', PRODUCT_PRICE)
        if total < 0.00:
            return await edit_or_reply(update, f"❌ O valor mínimo para pagamentos via Pix é *R$ 0.00*.\n\nSua compra atual de {qty}x custa *R$ {total:.2f}*.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ VOLTAR", callback_data='buy_menu')]]))

        if not MERCADOPAGO_TOKEN: return await query.answer("❌ Sistema não configurado.", show_alert=True)
        await edit_or_reply(update, "⏳ *GERANDO SEU PAGAMENTO PIX...*")
        try:
            sdk = mercadopago.SDK(MERCADOPAGO_TOKEN)
            payment_data = {"transaction_amount": float(total), "description": f"Compra {qty}x {PRODUCT_NAME}", "payment_method_id": "pix", "payer": {"email": f"user_{user_id}@breonnstore.com"}}
            payment = sdk.payment().create(payment_data)
            if payment["status"] == 201:
                qr_code, qr_code_64, p_id = payment["response"]["point_of_interaction"]["transaction_data"]["qr_code"], payment["response"]["point_of_interaction"]["transaction_data"]["qr_code_base64"], payment["response"]["id"]
                inventory.db.add_payment(str(p_id), user_id, total)
                qr = qrcode.QRCode(version=1, box_size=10, border=5)
                qr.add_data(qr_code)
                qr.make(fit=True)
                img = qr.make_image(fill_color="black", back_color="white")
                bio = io.BytesIO()
                img.save(bio)
                bio.seek(0)
                caption = f"💠 *PAGAMENTO PIX GERADO!*\n\n💰 Valor: `R$ {total:.2f}`\n📦 Qtd: `{qty}x`\n\n🔹 *Copia e Cola:* `{qr_code}`\n\n⚠️ O pagamento é verificado automaticamente."
                keyboard = [[InlineKeyboardButton("📋 COPIAR PIX / VERIFICAR", callback_data=f'copy_pix_{p_id}')], [InlineKeyboardButton("❌ CANCELAR", callback_data='back')]]
                await context.bot.send_photo(chat_id=user_id, photo=bio, caption=caption, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
                asyncio.create_task(verify_pix_loop(context, user_id, str(p_id), total, is_recharge=False))
            else: await edit_or_reply(update, "❌ Erro ao gerar PIX.")
        except Exception as e: await edit_or_reply(update, f"❌ Erro: {e}")

    elif query.data == 'add_balance_info':
        mult = float(inventory.db.get_setting('bonus_multiplier', '1.0'))
        bonus_text = f"\n\n🎁 *BÔNUS ATIVO:* `{int((mult-1)*100)}%` em qualquer recarga!" if mult > 1.0 else ""
        text = (f"💳 *ADICIONAR SALDO*\n\nSelecione um valor abaixo para recarregar ou clique em digitar valor (valor mínimo 1R$).{bonus_text}")
        keyboard = [
            [InlineKeyboardButton("R$ 5,00", callback_data='add_val_5'), InlineKeyboardButton("R$ 10,00", callback_data='add_val_10')],
            [InlineKeyboardButton("R$ 20,00", callback_data='add_val_20'), InlineKeyboardButton("R$ 50,00", callback_data='add_val_50')],
            [InlineKeyboardButton("⌨️ DIGITAR VALOR", callback_data='add_manual_value')],
            [InlineKeyboardButton("⬅️ VOLTAR", callback_data='back')]
        ]
        await edit_or_reply(update, text, reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data == 'add_manual_value':
        context.user_data[user_id] = {'waiting_balance_value': True}
        await edit_or_reply(update, "⌨️ *DIGITE O VALOR DA RECARGA:*\n\n💡 Exemplo: `5.00`, `10.00` ou `50.00`")

    elif query.data.startswith('add_val_'):
        amount = float(query.data.split('_')[2])
        if not MERCADOPAGO_TOKEN: return await query.answer("❌ Sistema não configurado.", show_alert=True)
        await edit_or_reply(update, "⏳ *GERANDO SEU PIX...*")
        try:
            sdk = mercadopago.SDK(MERCADOPAGO_TOKEN)
            payment_data = {"transaction_amount": float(amount), "description": f"Recarga de Saldo - {STORE_NAME}", "payment_method_id": "pix", "payer": {"email": f"user_{user_id}@breonnstore.com"}}
            payment = sdk.payment().create(payment_data)
            if payment["status"] == 201:
                qr_code, qr_code_64, p_id = payment["response"]["point_of_interaction"]["transaction_data"]["qr_code"], payment["response"]["point_of_interaction"]["transaction_data"]["qr_code_base64"], payment["response"]["id"]
                inventory.db.add_payment(str(p_id), user_id, amount)
                qr = qrcode.QRCode(version=1, box_size=10, border=5)
                qr.add_data(qr_code)
                qr.make(fit=True)
                img = qr.make_image(fill_color="black", back_color="white")
                bio = io.BytesIO()
                img.save(bio)
                bio.seek(0)
                caption = f"💠 *PAGAMENTO PIX GERADO!*\n\n💰 Valor: `R$ {amount:.2f}`\n\n🔹 *Copia e Cola:* `{qr_code}`\n\n⚠️ O saldo será adicionado automaticamente após o pagamento."
                keyboard = [[InlineKeyboardButton("📋 COPIAR PIX / VERIFICAR", callback_data=f'copy_pix_{p_id}')], [InlineKeyboardButton("❌ CANCELAR", callback_data='back')]]
                await context.bot.send_photo(chat_id=user_id, photo=bio, caption=caption, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
                asyncio.create_task(verify_pix_loop(context, user_id, str(p_id), amount, is_recharge=True))
            else: await edit_or_reply(update, "❌ Erro ao gerar PIX.")
        except Exception as e: await edit_or_reply(update, f"❌ Erro: {e}")

    elif query.data.startswith('copy_pix_'):
        p_id = query.data.split('_')[2]
        p = inventory.db.get_payment(p_id)
        if p:
            sdk = mercadopago.SDK(MERCADOPAGO_TOKEN)
            payment = sdk.payment().get(p_id)
            if payment["status"] == 200:
                qr_code = payment["response"]["point_of_interaction"]["transaction_data"]["qr_code"]
                if payment["response"]["status"] == 'approved':
                    await query.answer("✅ Pagamento já aprovado!", show_alert=True)
                    await process_approved_payment(context, user_id, p_id, p[2])
                else:
                    await query.answer(f"Copiado: {qr_code[:20]}...", show_alert=False)
            else: await query.answer("❌ Erro ao verificar pagamento.")
        else: await query.answer("❌ Pagamento não encontrado.")

    elif query.data == 'apply_coupon':
        context.user_data[user_id]['waiting_coupon'] = True
        await edit_or_reply(update, "🎫 *DIGITE O CÓDIGO DO CUPOM:*")

async def verify_pix_loop(context, user_id, payment_id, amount, is_recharge=True):
    attempts = 0
    sdk = mercadopago.SDK(MERCADOPAGO_TOKEN)
    while attempts < 60: # 10 minutos (10s cada tentativa)
        try:
            payment = sdk.payment().get(payment_id)
            if payment["status"] == 200 and payment["response"]["status"] == 'approved':
                await process_approved_payment(context, user_id, payment_id, amount, is_recharge)
                break
        except: pass
        await asyncio.sleep(10)
        attempts += 1

async def process_approved_payment(context, user_id, payment_id, amount, is_recharge=True):
    p = inventory.db.get_payment(payment_id)
    if not p or p[3] == 'approved': return
    inventory.db.update_payment_status(payment_id, 'approved')
    if is_recharge:
        inventory.db.update_balance(user_id, amount)
        await context.bot.send_message(chat_id=user_id, text=f"✅ *PAGAMENTO APROVADO!*\n\n💰 Foi creditado `R$ {amount:.2f}` em seu saldo.", parse_mode='Markdown')
        # Busca dados do usuário para o log
        user_db = inventory.db.get_user(user_id)
        user_obj = type('User', (), {'id': user_id, 'username': user_db[1] if user_db else 'Desconhecido'})
        await send_log(context, "RECARGA_PIX_AUTO", f"R$ {amount:.2f}", user_obj)
    else:
        # Busca dados do usuário para o log
        user_db = inventory.db.get_user(user_id)
        user_obj = type('User', (), {'id': user_id, 'username': user_db[1] if user_db else 'Desconhecido'})
        await send_log(context, "COMPRA_PIX_DIRETA", f"R$ {amount:.2f}", user_obj)
        u_data = context.user_data.get(user_id, {})
        qty, total = u_data.get('qty'), u_data.get('total')
        if qty and total and abs(total - amount) < 0.01:
            accounts = inventory.db.get_and_reserve_accounts(user_id, qty, total/qty)
            if accounts:
                # Registra o uso do cupom se houver um aplicado
                coupon_code = u_data.get('coupon')
                if coupon_code:
                    inventory.db.use_coupon(user_id, coupon_code)
                
                await context.bot.send_message(chat_id=user_id, text=f"✅ *PAGAMENTO APROVADO!*\n\n⏳ *ENTREGANDO {qty}x...*", parse_mode='Markdown')
                tutorial_button = InlineKeyboardMarkup([[InlineKeyboardButton("🎥 TUTORIAL", url="https://youtu.be/UrZfPCLQLaw")]])
                for acc_id, filename in accounts:
                    file_path = os.path.join(ACCOUNTS_DIR, filename)
                    if os.path.exists(file_path):
                        with open(file_path, 'rb') as f:
                            await context.bot.send_document(chat_id=user_id, document=f, caption=f"🎁 *CONTA ENTREGUE!*", reply_markup=tutorial_button, parse_mode='Markdown')
                        dest_path = os.path.join(SOLD_DIR, filename)
                        shutil.move(file_path, dest_path)
                context.user_data[user_id]['waiting_feedback'] = True
                return
        inventory.db.update_balance(user_id, amount)
        await context.bot.send_message(chat_id=user_id, text=f"✅ *PAGAMENTO APROVADO!*\n\n💰 Valor: `R$ {amount:.2f}`\n\nComo a sessão de compra expirou, o valor foi adicionado ao seu saldo. Por favor, use seu saldo para finalizar a compra no menu.", parse_mode='Markdown')

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id, user = update.effective_user.id, update.effective_user
    photo, caption = update.message.photo[-1].file_id, update.message.caption or ""
    if context.user_data.get(user_id, {}).get('waiting_feedback'):
        await send_feedback_to_channel(context, user, message_text=caption, photo=photo)
        await update.message.reply_text("📸 *Feedback visual enviado!* Obrigado.", parse_mode='Markdown')
        context.user_data[user_id]['waiting_feedback'] = False

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id, user, text = update.effective_user.id, update.effective_user, update.message.text.strip()
    u = inventory.db.get_user(user_id)
    if u and u[5]: return

    user_data = context.user_data.get(user_id, {})
    if user_data.get('waiting_buy_qty'):
        try:
            qty, count = int(text), inventory.get_stock_info()
            is_reseller = user_data.get('is_reseller_waiting', False)
            if qty <= 0 or qty > count: 
                return await update.message.reply_text(f"❌ Quantidade inválida. Estoque: `{count}`", parse_mode='Markdown')
            price = float(inventory.db.get_setting('reseller_price', 0.40)) if is_reseller else PRODUCT_PRICE
            total = price * qty
            if total < 0.29:
                return await update.message.reply_text(f"❌ O valor mínimo para compra com saldo é *R$ 0.29*.\n\nSua compra atual de {qty}x custa *R$ {total:.2f}*.\nAumente a quantidade para continuar.", parse_mode='Markdown')

            context.user_data[user_id]['waiting_buy_qty'] = False
            context.user_data[user_id].update({'qty': qty, 'total': total, 'is_reseller': is_reseller})
            text_menu = (f"🛒 *CONFIRMAR COMPRA*\n\n📦 Produto: {PRODUCT_NAME}\n🔢 Qtd: `{qty}`\n💰 Total: `R$ {total:.2f}`")
            keyboard = [[InlineKeyboardButton("💰 PAGAR COM SALDO", callback_data='pay_balance')],
                        [InlineKeyboardButton("⚡ PAGAR VIA PIX (GERAR QR)", callback_data='pay_pix')]]
            if not is_reseller:
                keyboard.append([InlineKeyboardButton("🎫 USAR CUPOM (%)", callback_data='apply_coupon')])
            keyboard.append([InlineKeyboardButton("⬅️ VOLTAR", callback_data='reseller_menu' if is_reseller else 'buy_menu')])
            await update.message.reply_text(text_menu, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
            return
        except: return await update.message.reply_text("❌ Digite um número válido.")

    if user_data.get('waiting_balance_value'):
        try:
            amount = float(text)
            if amount < 1.00: return await update.message.reply_text("❌ O valor mínimo para recarga é *R$ 1.00*.", parse_mode='Markdown')
            context.user_data[user_id]['waiting_balance_value'] = False
            text_menu = f"💳 *RECARGA*\n\n💰 Valor: `R$ {amount:.2f}`"
            keyboard = [[InlineKeyboardButton(f"✅ GERAR PIX (R$ {amount:.2f})", callback_data=f'add_val_{amount}')],
                        [InlineKeyboardButton("⬅️ VOLTAR", callback_data='add_balance_info')]]
            await update.message.reply_text(text_menu, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
            return
        except: return await update.message.reply_text("❌ Valor inválido.")

    if user_data.get('waiting_coupon'):
        success, result = inventory.db.validate_coupon(user_id, text)
        if success:
            discount, old_total = result['value'], context.user_data[user_id]['total']
            new_total = old_total * (1 - (discount / 100))
            context.user_data[user_id].update({'total': new_total, 'coupon': text.upper(), 'waiting_coupon': False})
            qty = context.user_data[user_id].get('qty', 1)
            text_menu = f"✅ *CUPOM APLICADO!*\n📉 Desconto: `{discount}%`\n💰 Novo Total: `R$ {new_total:.2f}`\n\n🛒 *CONFIRMAR COMPRA*\n\n📦 Qtd: `{qty}`"
            keyboard = [
                [InlineKeyboardButton("💰 PAGAR COM SALDO", callback_data='pay_balance')],
                [InlineKeyboardButton("⚡ PAGAR VIA PIX (GERAR QR)", callback_data='pay_pix')],
                [InlineKeyboardButton("⬅️ VOLTAR", callback_data='buy_menu')]
            ]
            await update.message.reply_text(text_menu, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
        else: await update.message.reply_text(f"❌ {result}")
        return

    if user_data.get('waiting_feedback') and not text.startswith('/'):
        await send_feedback_to_channel(context, user, message_text=text)
        await update.message.reply_text("🙏 *Obrigado pelo feedback!*", parse_mode='Markdown')
        context.user_data[user_id]['waiting_feedback'] = False

async def cmd_estoque(update: Update, context: ContextTypes.DEFAULT_TYPE):
    count = inventory.get_stock_info()
    text = f"📦 *ESTOQUE ATUAL*\nTemos `{count}` contas disponíveis! ⚡"
    reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ VOLTAR", callback_data='back')]])
    if update.callback_query: await edit_or_reply(update, text, reply_markup=reply_markup)
    else: await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def cmd_perfil(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = inventory.db.get_user(update.effective_user.id)
    cargos = {0: "Usuário", 1: "Admin", 2: "SubDono", 3: "Dono", 6: "Revendedor"}
    cargo_nome = "Dono" if is_owner(u[0], u[1]) else cargos.get(u[6], "Usuário")
    text = (f"👤 *SEU PERFIL*\n🆔 ID: `{u[0]}`\n💰 Saldo: `R$ {u[2]:.2f}`\n🎖️ Cargo: `{cargo_nome}`\n🛒 Gasto: `R$ {u[4]:.2f}`")
    keyboard = [[InlineKeyboardButton("💳 ADICIONAR SALDO", callback_data='add_balance_info')], [InlineKeyboardButton("⬅️ VOLTAR", callback_data='back')]]
    if update.callback_query: await edit_or_reply(update, text, reply_markup=InlineKeyboardMarkup(keyboard))
    else: await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')

async def cmd_rank(update: Update, context: ContextTypes.DEFAULT_TYPE):
    top = inventory.db.get_top_buyers(10)
    text = "🏆 *RANKING DE COMPRADORES*\n\n"
    for i, (name, spent, u_id) in enumerate(top, 1):
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "👤"
        text += f"{medal} {i}º - @{name or u_id}: `R$ {spent:.2f}`\n"
    reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ VOLTAR", callback_data='back')]])
    if update.callback_query: await edit_or_reply(update, text, reply_markup=reply_markup)
    else: await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def cmd_suporte(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = f"🆘 *SUPORTE*\n👤 Atendimento: @{DONO_USERNAME}"
    reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ VOLTAR", callback_data='back')]])
    if update.callback_query: await edit_or_reply(update, text, reply_markup=reply_markup)
    else: await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def get_my_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"🆔 Seu ID: `{update.effective_user.id}`", parse_mode='Markdown')

async def admin_importar_json(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Importa contas diretamente de um arquivo JSON enviado pelo Telegram"""
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    
    if not update.message.document or not update.message.document.file_name.endswith('.json'):
        return await update.message.reply_text("❌ Por favor, envie um arquivo `.json` válido.")

    status_msg = await update.message.reply_text("⏳ *Processando arquivo...*", parse_mode='Markdown')
    
    try:
        # Download do arquivo
        file = await context.bot.get_file(update.message.document.file_id)
        file_bytes = await file.download_as_bytearray()
        content = file_bytes.decode('utf-8')
        
        count = 0
        internal_name = "guest100067.dat"
        
        # Processa linha por linha
        for line in content.splitlines():
            line = line.strip()
            if not line: continue
            
            try:
                data = json.loads(line)
                if "guest_account_info" in data:
                    info = data["guest_account_info"]
                    # Reorganiza no formato correto
                    ordered_info = {}
                    if "com.garena.msdk.guest_password" in info:
                        ordered_info["com.garena.msdk.guest_password"] = info["com.garena.msdk.guest_password"]
                    if "com.garena.msdk.guest_uid" in info:
                        ordered_info["com.garena.msdk.guest_uid"] = info["com.garena.msdk.guest_uid"]
                    
                    json_content = json.dumps({"guest_account_info": ordered_info})
                    
                    # Cria o ZIP
                    count += 1
                    zip_filename = f"import_{update.effective_user.id}_{count}.zip"
                    zip_path = os.path.join(ACCOUNTS_DIR, zip_filename)
                    
                    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                        zipf.writestr(internal_name, json_content)
            except: continue

        if count > 0:
            # Chama a organização automática
            added = inventory.organize_stock()
            await status_msg.edit_text(f"✅ *SUCESSO!*\n\n📦 Contas processadas: `{count}`\n🔄 Estoque sincronizado!\n📦 Total no estoque: `{added}`", parse_mode='Markdown')
            await send_log(context, "IMPORT_JSON", f"Importou {count} contas via JSON", update.effective_user)
        else:
            await status_msg.edit_text("❌ Nenhuma conta válida encontrada no arquivo.")
            
    except Exception as e:
        await status_msg.edit_text(f"❌ Erro ao processar: {e}")

async def admin_converter_json(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Recebe um JSON e devolve um ZIP com arquivos .dat individuais"""
    if not is_admin_user(update.effective_user.id, update.effective_user.username): return
    
    if not update.message.document or not update.message.document.file_name.endswith('.json'):
        return await update.message.reply_text("❌ Por favor, envie um arquivo `.json` para converter.")

    status_msg = await update.message.reply_text("⏳ *Convertendo JSON para .dat...*", parse_mode='Markdown')
    
    try:
        # Download do arquivo JSON
        file = await context.bot.get_file(update.message.document.file_id)
        file_bytes = await file.download_as_bytearray()
        content = file_bytes.decode('utf-8')
        
        # Pasta temporária para criar os .dat
        temp_dir = os.path.join(BASE_DIR, f"temp_conv_{update.effective_user.id}")
        if os.path.exists(temp_dir): shutil.rmtree(temp_dir)
        os.makedirs(temp_dir)
        
        count = 0
        for line in content.splitlines():
            line = line.strip()
            if not line: continue
            
            try:
                data = json.loads(line)
                if "guest_account_info" in data:
                    count += 1
                    info = data["guest_account_info"]
                    ordered_info = {}
                    if "com.garena.msdk.guest_password" in info:
                        ordered_info["com.garena.msdk.guest_password"] = info["com.garena.msdk.guest_password"]
                    if "com.garena.msdk.guest_uid" in info:
                        ordered_info["com.garena.msdk.guest_uid"] = info["com.garena.msdk.guest_uid"]
                    
                    json_content = json.dumps({"guest_account_info": ordered_info})
                    
                    with open(os.path.join(temp_dir, f"conta{count}.dat"), 'w') as f:
                        f.write(json_content)
            except: continue

        if count > 0:
            # Criar o arquivo ZIP
            zip_filename = f"contas_convertidas_{count}.zip"
            zip_path = os.path.join(BASE_DIR, zip_filename)
            
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, _, files in os.walk(temp_dir):
                    for file in files:
                        zipf.write(os.path.join(root, file), file)
            
            # Enviar o ZIP de volta para o usuário
            with open(zip_path, 'rb') as f:
                await update.message.reply_document(
                    document=f, 
                    filename=zip_filename,
                    caption=f"✅ *CONVERSÃO CONCLUÍDA!*\n\n📦 Total de contas: `{count}`\n📂 Formato: `.dat` individual",
                    parse_mode='Markdown'
                )
            
            # Limpeza
            os.remove(zip_path)
            shutil.rmtree(temp_dir)
            await status_msg.delete()
        else:
            await status_msg.edit_text("❌ Nenhuma conta válida encontrada no JSON.")
            shutil.rmtree(temp_dir)
            
    except Exception as e:
        await status_msg.edit_text(f"❌ Erro na conversão: {e}")
